-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: db_dlaudo_erp
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `geo_activo_componente`
--

DROP TABLE IF EXISTS `geo_activo_componente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `geo_activo_componente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_activo` int NOT NULL,
  `componente` varchar(100) DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  `lat` varchar(50) DEFAULT NULL,
  `long` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_geo_activo_componente_ativo` (`id_activo`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_activo_componente`
--

LOCK TABLES `geo_activo_componente` WRITE;
/*!40000 ALTER TABLE `geo_activo_componente` DISABLE KEYS */;
/*!40000 ALTER TABLE `geo_activo_componente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo_bairro`
--

DROP TABLE IF EXISTS `geo_bairro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `geo_bairro` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bairro` varchar(50) DEFAULT NULL,
  `id_cidade` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_geo_bairro_cidade` (`id_cidade`),
  CONSTRAINT `fk_geo_bairro_cidade` FOREIGN KEY (`id_cidade`) REFERENCES `geo_cidade` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_bairro`
--

LOCK TABLES `geo_bairro` WRITE;
/*!40000 ALTER TABLE `geo_bairro` DISABLE KEYS */;
INSERT INTO `geo_bairro` VALUES (1,'Muzuane',3),(2,'Nauaia',3),(3,'Mathapue',3),(4,'Chivato',3),(5,'Maiaia',3),(6,'Mocone',3),(7,'Muanona',3),(8,'Mucuaipa',3),(9,'Murrupelanes',3),(10,'Nablusa',3),(11,'Naherenque',3),(12,'Nanari',3),(13,'Ontupaia',3),(14,'Quissimajulo',3),(15,'Ribaue',3),(16,'Triangulo',3);
/*!40000 ALTER TABLE `geo_bairro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo_cidade`
--

DROP TABLE IF EXISTS `geo_cidade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `geo_cidade` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cidade` varchar(50) DEFAULT NULL,
  `Provincia` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_cidade`
--

LOCK TABLES `geo_cidade` WRITE;
/*!40000 ALTER TABLE `geo_cidade` DISABLE KEYS */;
INSERT INTO `geo_cidade` VALUES (1,'Memba','Nampula'),(2,'Nacala-velha','Nampula'),(3,'Nacala-porto','Nampula'),(4,'Namialo','Nampula'),(5,'Monapo','Nampula'),(6,'Pemba','Cabo Delgado');
/*!40000 ALTER TABLE `geo_cidade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo_poste`
--

DROP TABLE IF EXISTS `geo_poste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `geo_poste` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `latitude` varchar(50) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL,
  `altitude` decimal(6,2) DEFAULT NULL,
  `precisao_gps` decimal(5,2) DEFAULT NULL,
  `id_tipo_poste` int DEFAULT NULL,
  `id_bairro` int DEFAULT NULL,
  `altura` decimal(4,2) DEFAULT NULL,
  `material` varchar(50) DEFAULT NULL,
  `ano_instalacao` bigint DEFAULT NULL,
  `concessionaria` varchar(50) DEFAULT NULL,
  `possui_aterramto` tinyint(1) DEFAULT NULL,
  `resistencia_atrramto` varchar(50) DEFAULT NULL,
  `data_ultima_medicao` date DEFAULT NULL,
  `tipo_isolamento` varchar(50) DEFAULT NULL,
  `estado_isolmnt` char(10) DEFAULT NULL,
  `nivel_risco` varchar(50) DEFAULT NULL,
  `pontuacao_risco` int DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  `cadastrado_por` varchar(50) DEFAULT NULL,
  `fonte_dados` varchar(50) DEFAULT NULL,
  `imgem` longblob,
  PRIMARY KEY (`id`),
  KEY `fk_geo_poste_tipo` (`id_tipo_poste`),
  KEY `fk_geo_poste_bairro` (`id_bairro`),
  CONSTRAINT `fk_geo_poste_bairro` FOREIGN KEY (`id_bairro`) REFERENCES `geo_bairro` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_geo_poste_tipo` FOREIGN KEY (`id_tipo_poste`) REFERENCES `geo_tipo_poste` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_poste`
--

LOCK TABLES `geo_poste` WRITE;
/*!40000 ALTER TABLE `geo_poste` DISABLE KEYS */;
/*!40000 ALTER TABLE `geo_poste` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo_postecadastro`
--

DROP TABLE IF EXISTS `geo_postecadastro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `geo_postecadastro` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `latitude` varchar(50) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL,
  `altitude` decimal(6,2) DEFAULT NULL,
  `precisao_gps` decimal(5,2) DEFAULT NULL,
  `id_tipo_poste` int DEFAULT NULL,
  `id_bairro` int DEFAULT NULL,
  `altura` decimal(4,2) DEFAULT NULL,
  `material` varchar(50) DEFAULT NULL,
  `ano_instalacao` bigint DEFAULT NULL,
  `concessionaria` varchar(50) DEFAULT NULL,
  `possui_aterramto` tinyint(1) DEFAULT NULL,
  `resistencia_atrramto` varchar(50) DEFAULT NULL,
  `data_ultima_medicao` date DEFAULT NULL,
  `tipo_isolamento` varchar(50) DEFAULT NULL,
  `estado_isolmnt` char(10) DEFAULT NULL,
  `nivel_risco` varchar(50) DEFAULT NULL,
  `pontuacao_risco` int DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  `cadastrado_por` varchar(50) DEFAULT NULL,
  `fonte_dados` varchar(50) DEFAULT NULL,
  `imgem` longblob,
  PRIMARY KEY (`id`),
  KEY `fk_geo_postecadastro_tipo` (`id_tipo_poste`),
  KEY `fk_geo_postecadastro_bairro` (`id_bairro`),
  CONSTRAINT `fk_geo_postecadastro_bairro` FOREIGN KEY (`id_bairro`) REFERENCES `geo_bairro` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_geo_postecadastro_tipo` FOREIGN KEY (`id_tipo_poste`) REFERENCES `geo_tipo_poste` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_postecadastro`
--

LOCK TABLES `geo_postecadastro` WRITE;
/*!40000 ALTER TABLE `geo_postecadastro` DISABLE KEYS */;
/*!40000 ALTER TABLE `geo_postecadastro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo_tipo_poste`
--

DROP TABLE IF EXISTS `geo_tipo_poste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `geo_tipo_poste` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo_poste` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_tipo_poste`
--

LOCK TABLES `geo_tipo_poste` WRITE;
/*!40000 ALTER TABLE `geo_tipo_poste` DISABLE KEYS */;
INSERT INTO `geo_tipo_poste` VALUES (1,'Poste De Ferro'),(2,'Linha De Alta Tensão'),(3,'Linha De Média Tensão'),(4,'Linha De Baixa Tensão'),(10,'PT'),(11,'Linha Subterrânea'),(12,'Poste De Madeira'),(13,'Poste De Betão');
/*!40000 ALTER TABLE `geo_tipo_poste` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nivel_acesso`
--

DROP TABLE IF EXISTS `nivel_acesso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nivel_acesso` (
  `id` int NOT NULL AUTO_INCREMENT,
  `desc_nivel_acesso` varchar(150) NOT NULL,
  `nivel` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nivel_acesso`
--

LOCK TABLES `nivel_acesso` WRITE;
/*!40000 ALTER TABLE `nivel_acesso` DISABLE KEYS */;
INSERT INTO `nivel_acesso` VALUES (1,'admin',1),(2,'user',2);
/*!40000 ALTER TABLE `nivel_acesso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `senha` longtext,
  `Id_nivel_acesso` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_usuario_nivel_acesso` (`Id_nivel_acesso`),
  CONSTRAINT `fk_usuario_nivel_acesso` FOREIGN KEY (`Id_nivel_acesso`) REFERENCES `nivel_acesso` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (9,'adminx','$2a$10$pQ26GUAkixMIlMfAY0Nke.lDRvI2IRaahmB1d3XmGy44wpxGVL1lO',1),(10,'salimo franca','$2a$10$qTkAs5s8MyNu85a0sZ2XtukfTJN/6SRhg617TPxRhzJMQzDgiWAKG',2);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_user`
--

DROP TABLE IF EXISTS `v_user`;
/*!50001 DROP VIEW IF EXISTS `v_user`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user` AS SELECT 
 1 AS `id`,
 1 AS `username`,
 1 AS `senha`,
 1 AS `Id_nivel_acesso`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_user`
--

/*!50001 DROP VIEW IF EXISTS `v_user`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user` AS select `usuario`.`id` AS `id`,`usuario`.`username` AS `username`,`usuario`.`senha` AS `senha`,`usuario`.`Id_nivel_acesso` AS `Id_nivel_acesso` from `usuario` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-02 20:32:43
